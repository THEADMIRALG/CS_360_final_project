package com.example.project_2;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.example.project_2.placeholder.AccountDatabase;

public class MainActivity extends AppCompatActivity {
    EditText username;
    EditText password;
    Button loginBtn;
    Button signUpBtn;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.goalChangeBtn), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        AccountDatabase db = new AccountDatabase(MainActivity.this);
        username = findViewById(R.id.usernameInput);
        password = findViewById(R.id.passwordInput);
        loginBtn = findViewById(R.id.loginBtn);
        signUpBtn = findViewById(R.id.signUpBtn);

        loginBtn.setOnClickListener(v -> {
            Log.d("MainActivity", "Login button clicked");
            String user = username.getText().toString();
            String pass = password.getText().toString();
            long login_success = db.getAccount(user, pass);
            if(login_success != -1) {
                Intent intent = new Intent(this, MainActivity2.class);
                intent.putExtra("accountId", login_success);
                startActivity(intent);
            }
            else {
                Toast.makeText(MainActivity.this, "Invalid username or password", Toast.LENGTH_SHORT).show();
            }

        });

        signUpBtn.setOnClickListener(v -> {
            String user = username.getText().toString();
            String pass = password.getText().toString();
            long account_id = db.addAccount(user, pass);
            if(account_id != -1) {
                Toast.makeText(MainActivity.this, "Account created", Toast.LENGTH_SHORT).show();
                Intent intent = new Intent(this, MainActivity2.class);
                startActivity(intent);
            }
            else {
                Toast.makeText(MainActivity.this, "Account creation failed", Toast.LENGTH_SHORT).show();
            }
        });



    }
}