package com.example.project_2;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.os.UserHandle;
import android.text.format.DateFormat;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.project_2.placeholder.AccountDatabase;
import com.example.project_2.placeholder.Recycler;
import com.example.project_2.placeholder.WeeklyWeightDatabase;
import com.example.project_2.placeholder.WeeklyWeightEntity;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class MainActivity2 extends AppCompatActivity {
    private RecyclerView recyclerView;
    private Recycler recycler;
    private UserHandle userSQLiteHandler;
    private WeeklyWeightDatabase weeklyWeightDatabase;
    EditText weeklyText;
    EditText goalView;
    //Button changeGoalBtn;
    Button addWeightBtn;
    long accountId;


    @SuppressLint("WrongViewCast")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main2);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.goalChangeBtn), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        weeklyText = findViewById(R.id.weeklyText);
        goalView = findViewById(R.id.goalView);
        //changeGoalBtn = findViewById(R.id.goalChangeBtn);
        addWeightBtn = findViewById(R.id.addWeightBtn);
        recyclerView = findViewById(R.id.weightTable);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setItemAnimator(new DefaultItemAnimator());
        accountId = getIntent().getLongExtra("accountId", -1);
        weeklyWeightDatabase = new WeeklyWeightDatabase(this);
        List<WeeklyWeightEntity> weightList = getWeightList();
        recycler = new Recycler(weightList);
        recyclerView.setAdapter(recycler);

        addWeightBtn.setOnClickListener(v -> {
            Date d = new Date();
            CharSequence s = DateFormat.format("MMMM d, yyyy ", d.getTime());
            String weight = weeklyText.getText().toString();
            CharSequence date = s;
            weeklyWeightDatabase.addWeight(weight, date.toString(), (int) accountId);
            WeeklyWeightEntity weightEntity = new WeeklyWeightEntity(date.toString(), weight);
            Log.d("MainActivity", "Calling addWeight method");
            weightList.add(weightEntity);
            recycler.notifyItemInserted(weightList.size() - 1);
        });
    }

    private List<WeeklyWeightEntity> getWeightList() {
        List <WeeklyWeightEntity> weightList = new ArrayList<>();
        SQLiteDatabase weeklyWeight = weeklyWeightDatabase.getReadableDatabase();
        Cursor cursor = weeklyWeight.rawQuery("SELECT * FROM weeklyWeight WHERE accountId = ?", new String[] {String.valueOf(accountId)});
        if(cursor.moveToFirst()) {
            do {
                @SuppressLint("Range") String date = cursor.getString(cursor.getColumnIndex("date"));
                @SuppressLint("Range") String weight = cursor.getString(cursor.getColumnIndex("weight"));
                weightList.add(new WeeklyWeightEntity(date, weight));
            }
            while (cursor.moveToNext());
        }
        cursor.close();
        Log.d("MainActivity2", "Fetched weight list size: " + weightList.size());
        return weightList;
    }



}