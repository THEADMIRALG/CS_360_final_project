package com.example.project_2.placeholder;

import android.annotation.SuppressLint;
import android.content.ContentValues;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import com.example.project_2.MainActivity;

public class AccountDatabase extends SQLiteOpenHelper {



    public AccountDatabase(MainActivity mainActivity) {
        super(mainActivity, "accounts", null, 1);
    }

    private static final class accountTable {
        private static final String TABLE = "accounts";
        private static final String ID = "id";
        private static final String USERNAME = "username";
        private static final String PASSWORD = "password";
    }
    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE accounts (id INTEGER PRIMARY KEY, username TEXT, password TEXT)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("drop table if exists " + accountTable.TABLE);
        onCreate(db);
    }

    public long addAccount(String username, String password) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("username", username);
        values.put("password", password);
        if (username.isEmpty() || password.isEmpty()) {
            return -1;
        }
        long accountId;
        if (getAccount(username, password) != -1) {
            return -1;
        } else {
            accountId = db.insert(accountTable.TABLE, null, values);
        }
        return accountId;
    }

    @SuppressLint("Range")
    public long getAccount(String username, String password) {
        SQLiteDatabase db = getReadableDatabase();
        long id = -1;
        String sql = "SELECT * FROM " + accountTable.TABLE + " WHERE " + accountTable.USERNAME + " = ? AND " + accountTable.PASSWORD + " = ?";
        Cursor cursor = db.rawQuery(sql, new String[] {username, password});
        if(cursor.moveToFirst()) {
                id = cursor.getLong(cursor.getColumnIndex(accountTable.ID));

        }
        cursor.close();
        return id;
    }

}
