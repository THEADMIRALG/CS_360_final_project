/*package com.example.project_2.placeholder;

public @interface Entity {
}*/
