package com.example.project_2.placeholder;

import android.os.Looper;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.project_2.R;

import java.util.List;
import java.util.logging.Handler;
import java.util.logging.LogRecord;

public class Recycler extends RecyclerView.Adapter<Recycler.ViewHolder> {
    private List<WeeklyWeightEntity> weightList;

    public Recycler(List<WeeklyWeightEntity> weightList) {
        this.weightList = weightList;
    }

    @NonNull
    @Override
    public Recycler.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.r_view_row, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        String date = weightList.get(position).getDate();
        String weight = weightList.get(position).getWeight();
        holder.date.setText(date);
        holder.weight.setText(weight);
    }

    @Override
    public int getItemCount() {
        return weightList.size();
    }

    public void addWeight(WeeklyWeightEntity weight) {
        Log.d("MainActivity", "recycler weight add weight");
        weightList.add(weight);
        notifyItemInserted(weightList.size() - 1);
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        private TextView date;
        private TextView weight;

        public ViewHolder(final View view) {
            super(view);
            date = view.findViewById(R.id.date);
            weight = view.findViewById(R.id.weight);
        }
    }

}
