package com.example.project_2.placeholder;

import android.view.View;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import com.example.project_2.R;

public class ViewHolder extends RecyclerView.ViewHolder {
        private TextView date;
        private TextView weight;
        public ViewHolder(final View view) {
            super(view);
            date = view.findViewById(R.id.date);
            weight = view.findViewById(R.id.weight);
        }
    }
