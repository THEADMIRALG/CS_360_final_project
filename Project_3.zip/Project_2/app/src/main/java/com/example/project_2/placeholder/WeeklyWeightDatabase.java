package com.example.project_2.placeholder;

import android.content.ContentValues;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import com.example.project_2.MainActivity2;

public class WeeklyWeightDatabase extends SQLiteOpenHelper {

    public WeeklyWeightDatabase(MainActivity2 mainActivity) {
        super(mainActivity, "weeklyWeight", null, 1);
    }
    private static final class weightTable {
        private static final String TABLE = "weeklyWeight";
        private static final String ID = "id";
        private static final String DATE = "date";
        private static final String WEIGHT = "weight";
        private static final String ACCOUNT_ID = "accountId";
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE weeklyWeight (id INTEGER PRIMARY KEY, date TEXT, weight TEXT, accountId INTEGER)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("drop table if exists " + weightTable.TABLE);
        onCreate(db);
    }

    public long addWeight(String date, String weight, int accountId) {
        Log.d("MainActivity", "Calling weekly weight add weight");
        SQLiteDatabase db = getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("date", date);
        values.put("weight", weight);
        values.put("accountId", accountId);
        long weightId;
        if (weight.isEmpty()) {
            return -1;
        }
        else{
            weightId = db.insert(weightTable.TABLE, null, values);
            db.close();
        }

        return weightId;
    }


}
