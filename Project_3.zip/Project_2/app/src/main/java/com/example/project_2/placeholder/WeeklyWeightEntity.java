package com.example.project_2.placeholder;

import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.ForeignKey;
import androidx.room.PrimaryKey;

@Entity(foreignKeys = @ForeignKey(entity = AccountDatabase.class, parentColumns = "id", childColumns = "accountId"))
public class WeeklyWeightEntity {
    @PrimaryKey(autoGenerate = true)
    @ColumnInfo(name = "id")
    private long id;
    @ColumnInfo(name = "date")
    private String date;
    @ColumnInfo(name = "weight")
    private String weight;
    @ColumnInfo(name = "accountId")
    private long accountId;

    public WeeklyWeightEntity(String date, String weight) {
        this.date = date;
        this.weight = weight;
        this.accountId = accountId;
    }

    public int getId() {
        return (int) id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getWeight() {
        return weight;
    }

    public void setWeight(String weight) {
        this.weight = weight;
    }

    public long getAccountId() {
        return accountId;
    }

    public void setAccountId(long accountId) {
        this.accountId = accountId;
    }
}
