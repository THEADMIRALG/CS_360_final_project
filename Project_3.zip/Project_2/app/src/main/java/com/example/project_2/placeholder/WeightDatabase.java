package com.example.project_2.placeholder;

import android.content.ContentValues;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

import com.example.project_2.MainActivity;

public class WeightDatabase extends SQLiteOpenHelper {

    public WeightDatabase(MainActivity mainActivity) {
        super(mainActivity, "goal", null, 1);
    }

    private static final class weightTable {
        private static final String TABLE = "goal";
        private static final String ID = "id";
        private static final String weight = "weight";
    }

    @Override
    public  void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE goal (id INTEGER , weight TEXT)");

    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int oldVersion, int newVersion) {
        sqLiteDatabase.execSQL("drop table if exists " + weightTable.TABLE);
        onCreate(sqLiteDatabase);
    }

    public long addWeight(String weight) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("weight", weight);
        if (weight.isEmpty()) {
            return -1;
        }
        long weightId;
        if (getWeight(weight) != -1) {
            return -1;
        } else {
            weightId = db.insert(weightTable.TABLE, null, values);
        }
        return weightId;
    }

    private int getWeight(String weight) {
        SQLiteDatabase db = getReadableDatabase();
        String sql = "SELECT * FROM " + weightTable.TABLE + " WHERE " + weightTable.weight + " = ?";
        return db.rawQuery(sql, new String[] {weight}).getCount();
    }
}
